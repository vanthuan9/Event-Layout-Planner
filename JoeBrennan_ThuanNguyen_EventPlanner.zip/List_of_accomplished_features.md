# Event-Layout-Planner

Features completed by group member:

Joe Brennan:
- chair geometry
- coatrack geometry
- striped pattern
- heartbeat animation
- tab pick (and tab + shift multiple selection)
	- on 'TAB' for single pick, 'SHIFT' + 'TAB' for multiple selection
- grid position manipulation
	- on 'G'
- key rotate
	- on 'A' and 'D'
- object delete
	- on 'M'
- camera scroll
	- on 'I', 'J', 'K', and 'L'

Thuan Nguyen:
- Table(circle) geometry
- Lamp geometry
- Checkered pattern
- Blinking animation
- Mouse pick (and mouse + shift multiple selection)
- Arrow move
	- on arrow keys
- Zoom
	- on 'Z' and 'X'
- Mouse rotate
	- on mouse movement
- Add new (only one object can be created at a time)
	- 'KEY' then mouse-click
	- 'C' for chair
	- 'R' for coatrack
	- 'T' for table
	- 'E' for lamp
